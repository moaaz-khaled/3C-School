using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class View : MonoBehaviour
{
    Vector3 Distance;
    public GameObject ball;
    public bool isRotate = false;

    // Start is called before the first frame update
    void Start()
    {
        Distance = transform.position - ball.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Distance + ball.transform.position;
        if (isRotate)
        {
            transform.rotation = Quaternion.Euler(90f , ball.transform.eulerAngles.y , 0);
        }
    }
}
