using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float Speed = 4;
    Vector3 RandomPostion;

    void Start()
    {
        RandomPostion = setPosition();
    }

    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position , RandomPostion , Speed * Time.deltaTime);
        if(Vector3.Distance(transform.position , RandomPostion) < 1)
        {
            RandomPostion = setPosition();
        }
    }

    Vector3 setPosition()
    {
        Vector3 newPosition = new Vector3(Random.Range(-9 , 9) , transform.position.y , Random.Range(-9f , 9));
        return newPosition;
    }
}
