using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MoveBall : MonoBehaviour
{
    public float speed = 4;
    Rigidbody rb;
    public GameObject scoreText;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        Vector3 ballPosition = new Vector3(x, 0 , z);
        rb.AddForce(ballPosition * speed);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Cube")
        {
            Destroy(collision.gameObject);
            scoreText.GetComponent<Score>().score += 1;
            if(scoreText.GetComponent<Score>().score == 9)
            {
                SceneManager.LoadScene(2);
            }
        }
        if (collision.gameObject.tag == "Finish")
        {
            SceneManager.LoadScene(3);
        }
    }

}